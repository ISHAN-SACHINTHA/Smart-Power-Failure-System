<?php
	session_start();
    require 'db/db.php';
    if (isset($_SESSION['usName'])) {
        //header("location:app1.php?link=1");
        }

    
?>

<!DOCTYPE >
<html>
<head>
	<meta name="viewport"  content="width=device-width, inetial-scale=1" >
	<title>
		Smart Power Failure Detection System-Home
	</title> 
	<script src="js/jquery-3.4.1.js"></script>
	
	<link rel="stylesheet" type="text/css" href="css/home.css"/>

</head>

<body id="body" background="img/pic0.jpg" >
	
			<div class="in-div">
				<h2 id="site_name" class="blink-image">Ceylon Electricity Board</h2>
				<ul class="in-ul">
					<li><a class="in-a" onclick="document.getElementById('SignIn').style.display='block'">Sign In</a></li>
					<li><a class="in-a" onclick="document.getElementById('Signup').style.display='block'">Sign Up</a></li>
				</ul>
			</div> 
	
<script>
// When the user scrolls down 20px from the top of the document, slide down the navbar
	window.onscroll = function() {scrollFunction()};

	function scrollFunction() {
  		if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    		document.getElementById("in-div").style.top = "0";
  		} else {
    		document.getElementById("in-div").style.top = "0px";
  		}
	}

</script>

<br>
<div class="ceblogo">
	<img src="img/ceb.png">
</div>

<div class="site_name_text">
	<center> <span id="s1"> Smart Power Failure Detection System</span>  </center> <br> 
</div>
<br>
<br>

<div class="box1">
	<div class="box_img1" >
		<a href="pages/Position.php">
		<img src="img/logo02.png"></a>
		<h1 class="box1_text">Position</h1>
	</div>
	<div class="box_img1">
		<a href="pages/contactEngineer.php">
		<img src="img/logo01.png"></a>
		<h1 class="box1_text">Contact Engineer</h1>
	</div>
	<div class="box_img1">
		<a href="pages/ChangePswrd.php">
		<img src="img/logo3.png"></a>
		<h1 class="box1_text">Change Password</h1>
	</div>
    </div>

    <div id="Signin" class="modal">
		<form class="modal-content animate" action="pages/action1.php"  method="post">

			<div class="imgcontainer">
				<span onclick="document.getElementById('Signin').style.display='none'" class="close" title="Close">&times</span>
				<img src="img/logo04.png" alt="Avatar" class="avatar">
				<h1 style="text-align:center" class="popup-tital">Sign In</h1>
			</div>
			<div class="container">				
				<input type="ID" name="branchId" placeholder="Enter Branch ID" required>
				<input type="password" name="pass" placeholder="Enter Password" required>
				<button type="submit"  id="btn" name="Signin-btn">Sign In</button>
			</div>
	
		</form>
	</div>
	<div id="signup"  class="modal">
		<form class="modal-content animate"  method="post" action="pages/action1.php">
			<div class="imgcontainer">
				<span onclick="document.getElementById('signup').style.display='none'" class="close" title="Close">&times</span>
				<img src="img/logo04.png"  alt="Avatar" class="avatar">
				<h1 style="text-align:center" class="popup-tital">Sign Up</h1>
			</div>
			<div class="container">				
				<input type="id" id="oId" name="officerid" placeholder="Head Officer ID" required oninput="check_cname()"></h2>
				<input type="id" id="Bid" name="Branchid" placeholder="Branch ID" required oninput="check_uname()"></h2>
				<input type="text" id="email" name="email" placeholder="Branch E-mail" required oninput="check_email()"></h2>
				<input type="password" id="pass1" name="1pass" placeholder="Password" required oninput="check_pass1()"></h2>
				<input type="password" id="pass2" name="2pass" placeholder="Re-Enter Password " required oninput="check_pass2()"></h2>
				
				<button type="submit" name="sign-btn" id="btn">Sign Up</button>
			</div>
		</form>
	</div>

	<script>
		var modal=document.getElementById('Signin');
		window.onclick=function (event) {

			if (event.target==modal) {
				modal.style.display="none";
			}

		}
	</script>

	<script>
	
		var modal=document.getElementById('signup');
		window.onclick=function (event) {
			if (event.target==modal) {
				modal.style.display="none";
			}

		}
	</script>





</body>
</html>