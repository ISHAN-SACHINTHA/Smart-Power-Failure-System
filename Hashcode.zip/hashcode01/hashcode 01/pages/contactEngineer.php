<?php

    // Include db file
    require_once "db/db.php";

    // Define variables and initialize with empty values
    $branch_id ="";
    $branch_id_err ="";

    // Processing form data when form is submitted
    if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate branch_name
        if(empty(trim($_POST["branch_id"]))){

        	$branch_name_err = "Please enter a Branch ID.";
        }
        else{

        	// Prepare a select statement
            $sql = "SELECT branch_id FROM branch WHERE branch_name = ?";

            if($stmt = $mysqli->prepare($sql)){

            	

            }	


        }

    }    	


?>



<!DOCTYPE html>
<html>
<head>
	<title>Smart Power Failure Detection System - Contact Engineer</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">

	<link rel="stylesheet" type="text/css" href="css/contactEngineer.css"/>



</head>
<body>

	<div id="contactEngineer" class="modal">
		<h2><center>Contact Engineer</center> </h2>
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
			<div class="form-group <?php echo (!empty($branch_id_err)) ? 'has-error' : ''; ?>">
				<label>Branch ID</label>
				<input type="text" name="branch_id" class="form-control" value="<?php echo $branch_id; ?>">
				<span class="help-block"><?php echo $branch_id_err; ?></span>
				
			</div>

			<div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
			
		</form>
		
	</div>

</body>
</html>