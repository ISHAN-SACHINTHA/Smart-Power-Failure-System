<?php
    // Include db file
    require_once "db/db.php";

    // Define variables and initialize with empty values
    $branch_name =$branch_id = $branch_password = $confirm_branch_password = "";
    $branch_name_err =$branch_id_err = $branch_password_err = $confirm_branch_password_err = "";

    // Processing form data when form is submitted
    if($_SERVER["REQUEST_METHOD"] == "POST"){
    	// Validate branch_name
        if(empty(trim($_POST["branch_name"]))){

        	$branch_name_err = "Please enter a Branch Name.";
        }
        else{
        	// Prepare a select statement
            $sql = "SELECT branch_id FROM branch WHERE branch_name = ?";

            if($stmt = $mysqli->prepare($sql)){
            	// Bind variables to the prepared statement as parameters
                $stmt->bind_param("s", $param_branch_name);	

                // Set parameters
                $param_branch_name = trim($_POST["branch_name"]);

                // Attempt to execute the prepared statement
                if($stmt->execute()){

            	    // store result
                    $stmt->store_result();

                    if($stmt->num_rows == 1){

                	$branch_name_err = "This Branch Name is already taken.";
                    }

                    else{
                	$branch_name = trim($_POST["branch_name"]);
                    }	

                }
                else{
            	    echo "Oops! Something went wrong. Please try again later.";
                }

                // Close statement
                $stmt->close();	

            }

        }

        // Validate branch_password
        if(empty(trim($_POST["branch_password"]))){
        	$branch_password_err = "Please enter a Branch Password."; 

        }
        elseif (strlen(trim($_POST["branch_password"])) < 6) {
            $branch_password_err = "Password must have atleast 6 characters.";
        }	
        else{
        	$branch_password = trim($_POST["branch_password"]);
        }

        // Validate confirm password

        if(empty(trim($_POST["confirm_branch_password"]))){

        	$confirm_branch_password_err = "Please confirm Branch Password.";

        }
        else{
        	$confirm_branch_password = trim($_POST["confirm_branch_password"]);

        	if(empty($branch_password_err) && ($branch_password != $confirm_branch_password_err)){

        		$confirm_branch_password_err = "Password did not match.";

        	}	

        }

        // Check input errors before inserting in database
        if(empty($branch_name_err) && empty($branch_password_err) && empty($confirm_branch_password_err)){

        	// Prepare an insert statement
            $sql = "INSERT INTO branch (branch_name, branch_password) VALUES (?, ?)";

            if($stmt = $mysqli->prepare($sql)){
            	// Bind variables to the prepared statement as parameters
            	$stmt->bind_param("ss", $param_branch_name, $param_branch_password);

            	// Set parameters
                $param_branch_name = $branch_name;
                $param_branch_password = password_hash($branch_password, PASSWORD_DEFAULT); // Creates a password hash

                // Attempt to execute the prepared statement
                if($stmt->execute()){
                	// Redirect to login page
                    header("location: pages/signin.php");

                }
                else{
                	echo "Something went wrong. Please try again later.";

                }

                // Close statement
                $stmt->close();


            }

        }

        // Close connection
        $mysqli->close();	
    }   

?>

<!DOCTYPE html>
<html>
<head>

	<title>Smart Power Failure Detection System - Sign up</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">

	<link rel="stylesheet" type="text/css" href="css/signup.css"/>


</head>
<body>

	<div id="signup" class="modal">
		<h2><center>Sign Up</center> </h2>
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

			<div class="form-group <?php echo (!empty($branch_name_err)) ? 'has-error' : ''; ?>">

				<label>Branch Name</label>
				<input type="text" name="branch_name" class="form-control" value="<?php echo $branch_name; ?>">
				<span class="help-block"><?php echo $branch_name_err; ?></span>
				
			</div>

			<div class="form-group <?php echo (!empty($branch_id_err)) ? 'has-error' : ''; ?>">

				<label>Branch ID</label>
				<input type="text" name="branch_id" class="form-control" value="<?php echo $branch_id; ?>">
				<span class="help-block"><?php echo $branch_id_err; ?></span>
				
			</div>

			<div class="form-group <?php echo (!empty($branch_password_err)) ? 'has-error' : ''; ?>">

				<label>Branch Password</label>
				<input type="password" name="branch_password" class="form-control" value="<?php echo $branch_password; ?>">
				<span class="help-block"><?php echo $branch_password_err; ?></span>

			</div>

			<div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
                <label>Confirm Password</label>
                <input type="password" name="confirm_branch_password_err" class="form-control" value="<?php echo $confirm_branch_password_err; ?>">
                <span class="help-block"><?php echo $confirm_branch_password_err; ?></span>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>

            <p>Already have an account? <a href="pages/signin.php">SignIn here</a>.</p>
			
		</form>


	</div>

</body>
</html>