<?php
    //initialize the session
    session_start();

    //Check if the user is already logged in, if yes then redirect him to welcome page
    if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: pages/welcome.php");
    exit;
    }

    // Include datbase file
    require_once "db/db.php";

    // Define variables and initialize with empty values
    $branch_name = $branch_id = $branch_password = "";
    $branch_name_err = $branch_id_err = $branch_password_err = "";

    // Processing form data when form is submitted
    if($_SERVER["REQUEST_METHOD"] == "POST"){
 
        // Check if branch name is empty
        if(empty(trim($_POST["branch_name"]))){

            $branch_name_err = "Please enter Branch Name.";
        } 
        else{

            $branch_name = trim($_POST["branch_name"]);
        }

        // Check if branch_id is empty
        if(empty(trim($_POST["branch_id"]))){

            $branch_id_err = "Please enter your branch_id.";
        } 
        else{
            $branch_id = trim($_POST["branch_id"]);
        }

        // Check if branch_password is empty
        if(empty(trim($_POST["branch_password"]))){

            $branch_password_err = "Please enter your Branch Password.";
        }
        else{

            $branch_password = trim($_POST["branch_password"]);
        }

        // Validate credentials
        if(empty($branch_name_err) && empty($branch_password_err)){

        	// Prepare a select statement
            $sql = "SELECT branch_name, branch_id, branch_password FROM branch WHERE branch = ?";

            if($stmt = $mysqli->prepare($sql)){

                // Bind variables to the prepared statement as parameters
                $stmt->bind_param("s", $param_branch_name);

                // Set parameters
                $param_branch_name = $branch_name;

                // Attempt to execute the prepared statement
                if($stmt->execute()){

                	// Store result
                    $stmt->store_result();

                    // Check if branch name exists, if yes then verify password
                    if($stmt->num_rows == 1){  

                    	// Bind result variables
                        $stmt->bind_result($branch_id, $branch_name, $hashed_branch_password);

                        if($stmt->fetch()){

                        	if(password_verify($branch_password, $hashed_branch_password)){

                        		// Password is correct, so start a new session
                        		session_start();

                        		// Store data in session variables
                        		$_SESSION["loggedin"] = true;
                                $_SESSION["branch_id"] = $branch_id;
                                $_SESSION["branch_name"] = $branch_name;

                                // Redirect user to welcome page
                                header("location: welcome.php");

                        	}	
                        	else{
                        		// Display an error message if password is not valid
                                $branch_password_err = "The password you entered was not valid.";

                        	}

                        }	

                    }

                    else{

                    	// Display an error message if username doesn't exist
                    	$branch_name_err = "No account found with that username.";

                    }	

                }
                else{

                	echo "Oops! Something went wrong. Please try again later.";

                }

                // Close statement
                $stmt->close();
            
            }	

        }

        // Close connection
        $mysqli->close();
    }

?>



<!DOCTYPE html>
<html>


<head>
	<title>Smart Power Failure Detection System - Sign In</title>
    
    <script src="js/jquery-3.4.1.js"></script>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/signin.css"/>

</head>
<body id="body">
	<div id="signin" class="modal">
		<h2><center>Sign In</center> </h2>
		<p>Please fill in your credentials to login.</p>
		<hr>
		<hr>

		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

			<div class="form-group <?php echo(!empty($branch_name_err)) ? 'has-error' : ''; ?> ">
				<label>Branch Name</label>
				<input type="text" name="branch_name" class="form-control" value="<?php echo $branch_name; ?>">
				<span class="help-block"> <?php echo $branch_name_err; ?></span>	
			</div>

			
			<div class="form-group <?php echo (!empty($branch_id_err)) ? 'has-error' : ''; ?>">
                <label>Branch ID</label>
                <input type="text" name="branch_id" class="form-control">
                <span class="help-block"><?php echo $branch_id_err; ?></span>
            </div>

            <div class="form-group <?php echo (!empty($branch_password_err)) ? 'has-error' : ''; ?>">
                <label>Branch Password</label>
                <input type="password" name="branch_password" class="form-control">
                <span class="help-block"><?php echo $branch_password_err; ?></span>
            </div>

            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Sign In">
            </div>

            <p>Don't have an account <a href="pages/signup.php">Sign up now</a>.</p>
	
		</form>
	
    </div>

</body>
</html>