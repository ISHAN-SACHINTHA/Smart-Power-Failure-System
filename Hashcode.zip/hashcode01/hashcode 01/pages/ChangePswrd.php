<?php
    // Initialize the session
    session_start();

    // Check if the user is logged in, if not then redirect to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){

    	header("location: pages/signin.php");
        exit;

    }	

    // Include config file
    require_once "db/db.php";

    // Define variables and initialize with empty values
    $new_branch_password = $confirm_new_branch_password = "";
    $new_branch_password_err = $confirm_new_branch_password_err = "";

    // Processing form data when form is submitted
    if($_SERVER["REQUEST_METHOD"] == "POST"){
    	// Validate new password
        if(empty(trim($_POST["new_branch_password"]))){
        	$new_branch_password_err = "Please enter the new password."; 

        }
        elseif(strlen(trim($_POST["new_branch_password"])) < 6) {
        	$new_branch_password = "Password must have atleast 6 characters.";
        }

        else{
        	$new_branch_password = trim($_POST["new_branch_password"]);
        }

        // Validate confirm password
        if(empty(trim($_POST["confirm_new_branch_password"]))){

        	$confirm_new_branch_password_err = "Please confirm the password.";

        }
        else{
        	$confirm_new_branch_password = trim($_POST["confirm_new_branch_password"]);

        	if(empty($new_branch_password_err) && ($new_branch_password != $confirm_new_branch_password)){

        		$confirm_new_branch_password_err = "Password did not match.";

        	}	
        }

        // Check input errors before updating the database
        if(empty($new_branch_password_err) && empty($confirm_new_branch_password_err)){	

        	// Prepare an update statement
            $sql = "UPDATE branch SET branch_password = ? WHERE branch_id = ?";

            if($stmt = $mysqli->prepare($sql)){
            // Bind variables to the prepared statement as parameters

            	$stmt->bind_param("si", $param_branch_password, $param_branch_id);

            	// Set parameters
                $param_branch_password = password_hash($new_branch_password, PASSWORD_DEFAULT);

                $param_branch_id = $_SESSION["branch_id"];

                // Attempt to execute the prepared statement
                if($stmt->execute()){
                	// Password updated successfully. Destroy the session, and redirect to signin page

                	session_destroy();
                    header("location: pages/signin.php");
                    exit();

                }
                else{
                    echo "Oops! Something went wrong. Please try again later.";
                }

                // Close statement
                $stmt->close();

            }	

        }

        // Close connection
        $mysqli->close();	

    }	

?>

<!DOCTYPE html>
<html>
<head>
	<title>Smart Power Failure detection System - Change Password</title>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">

	<link rel="stylesheet" type="text/css" href="css/chngpswrd.css"/>
</head>
<body>
	<div class="modal">
		<h2>Change Password</h2>
		<p>Please fiil out this form to change password.</p>

		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 

			<div class="form-group <?php echo (!empty($new_branch_password_err)) ? 'has-error' : ''; ?>">

				<label>New Password</label>
				<input type="password" name="new_branch_password" class="form-control" value="<?php echo $new_branch_password; ?>">

				<span class="help-block"><?php echo $new_branch_password_err; ?></span>

			</div>	

			<div class="form-group <?php echo (!empty($confirm_new_branch_password_err)) ? 'has-error' : ''; ?>">

				<label>Confirm Password</label>
				<input type="password" name="confirm_new_branch_password" class="form-control">

				<span class="help-block"><?php echo $confirm_new_branch_password_err; ?></span>
				
			</div>

			<div class="form-group">
				<input type="submit" class="btn btn-primary" value="Submit">

				<a class="btn btn-link" href="pages/welcome.php">Cancel</a>
				
			</div>
			
		</form>
		
	</div>

</body>
</html>