<!DOCTYPE html>
<html>
<head>
	<title>Smart Power Failure Detection System - Sign Out</title>

</head>
<body>

</body>
</html>