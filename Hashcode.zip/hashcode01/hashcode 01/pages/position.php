<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="css/position.css"/>
    </head>
    <body>
    <h3>Google Maps </h3>
    <!--The div element for the map -->
    <div id="map"></div>
    <script>
    // Initialize and add the map
    function initMap() {
    // The location of Uluru
    var matara_ceb = {lat: 5.953013, lng: 80.537253};
    // The map, centered at matara_ceb
    var map = new google.maps.Map(document.getElementById('map'), {zoom: 4, center: matara_ceb});
  // The marker, positioned at matara_ceb
  var marker = new google.maps.Marker({position: matara_ceb, map: map});
}
    </script>
    <!--Load the API from the specified URL
    * The async attribute allows the browser to render the page while the API loads
    * The key parameter will contain your own API key (which is not needed for this tutorial)
    * The callback parameter executes the initMap() function
    -->
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&callback=initMap">
    </script>
  </body>
</html>