<!DOCTYPE html>
<html>
<head>
	<title>Smart Power Failure Detection System - Welcome</title>
	<script src="js/jquery-3.4.1.js"></script>
	<link rel="stylesheet" type="text/css" href="css/welcome.css"/>
</head>
<body background="img/pic0.jpg" id="body">
	<div class="in-div">
		<h2 id="site_name">Ceylon Electricity Board </h2>
		<ul class="in-ul">
			
		     <li><a class="in-a" onclick="document.getElementById('signout').style.display='block'" href="pages/signout.php">Sign Out</a>
		    </li>
		</ul>
	</div>
	<br>

	<div class="logo-img">
		<img src="img/ceb.png" >	
	</div>
	<br><br><br><br><br><br>

	<div class="site_textname">
		<center><strong><span id="s1">Smart Power Failure Detection System</span></strong></center>
		
	</div>
	<br><br><br>

	<div class="box1">
		<div class="box_img1">
			<a href="pages/position.php">
				<img src="img/logo02.png">
			</a>
			<h1 class="box1_text">Position</h1>
			
		</div>

		<div class="box_img1">
			<a href="pages/contactEngineer.php">
		        <img src="img/logo01.png">
		    </a>     
		        <h1 class="box1_text">Contact Engineer</h1>

		</div>

		<div class="box_img1">
		    <a href="pages/ChangePswrd.php">
		        <img src="img/logo3.png">
		    </a>
		        <h1 class="box1_text">Change Password</h1>

	    </div>
		
	</div>



</body>
</html>