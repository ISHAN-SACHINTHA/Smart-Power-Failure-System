<?php
	session_start();
    require 'db/db.php';
    if (isset($_SESSION['usName'])) {
           
        }

    
?>
<!DOCTYPE html>
<html>
<head>
	<title>Smart Power Failure Detection System</title>
	<script src="js/jquery-3.4.1.js"></script>
	<link rel="stylesheet" type="text/css" href="css/home.css"/>
</head>
<body background="img/pic0.jpg" id="body">
	<div class="in-div">
		<h2 id="site_name">Ceylon Electricity Board </h2>
		<ul class="in-ul">
			<li><a class="in-a" onclick="document.getElementById('signin').style.display='block'" href="pages/signin.php">Sign In</a></li>
		    <li><a class="in-a" onclick="document.getElementById('signup').style.display='block'" href="pages/signup.php">Sign Up</a>
		    </li>
		     <li><a class="in-a" onclick="document.getElementById('signout').style.display='block'" href="pages/signout.php">Sign Out</a>
		    </li>
		</ul>
	</div>
	<br>

	<div class="logo-img">
		<img src="img/ceb.png" >	
	</div>
	<br><br><br><br><br><br><br><br>

	<div class="site_textname">
		<center><strong><span id="s1">Smart Power Failure Detection System</span></strong></center>
		
	</div>
	<br><br><br>

	



</body>
</html>