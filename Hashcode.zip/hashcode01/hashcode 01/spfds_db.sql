CREATE TABLE branch (
    branch_id INT NOT NULL PRIMARY KEY,
    branch_name VARCHAR(50) NOT NULL UNIQUE,
    branch_password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);